To grade this assignment, run the following commands:

1. chmod +x dos2unix_script.sh
2. g++ -std=c++11 wrestler.cpp
3. ./a.out FILENAME.txt

In step 3, replace FILENAME.txt with the file containing the wrestler data.
