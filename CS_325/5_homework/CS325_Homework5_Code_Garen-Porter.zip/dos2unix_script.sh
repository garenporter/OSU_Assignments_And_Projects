#!/bin/bash

dos2unix $1
