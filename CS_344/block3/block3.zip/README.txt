$ gcc -o smallsh smallsh.c
$ p3testscript > mytestresults 2>&1
