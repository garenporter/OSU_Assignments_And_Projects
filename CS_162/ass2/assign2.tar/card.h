#include <string>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#pragma once

using namespace std;

struct card {
	int value; // 1-13
	string suit; // string each suit
	};


