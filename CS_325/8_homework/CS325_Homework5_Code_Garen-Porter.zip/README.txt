To compile and run the bin-packing code:
1. g++ binpack.cpp
2. ./a.out bin.txt

NOTE: bin.txt can be replaced with any filename that contains data for bin-packing.
NOTE: program will fail if no file is supplied as a command line argument.