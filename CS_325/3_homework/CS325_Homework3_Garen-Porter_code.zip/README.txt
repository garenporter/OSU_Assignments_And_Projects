The shopping.cpp file expects there to a be a file called shopping.txt to exist in the same directory.
shopping.cpp uses shopping.txt to aqcuire the neccessary data to run the algorithm.

shoppin.cpp outputs the results to a file called shopping.out.