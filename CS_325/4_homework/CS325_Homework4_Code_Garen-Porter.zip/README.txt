To compile and run, do the following commands in order:
1. g++ lastToStart.cpp
2. ./a.out

The program expects act.txt to exist in the same directory it is executed in.