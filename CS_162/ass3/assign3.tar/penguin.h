#include "./animal.h"
#pragma once

class penguin :public animal {
	public:
		penguin();
};
