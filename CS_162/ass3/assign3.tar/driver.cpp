#include "./zoo.h"
//#include "./animal.h"

int main() {
	zoo z;
//	tiger t, t2;

	z.get_starting_animals();
	z.play_game();

//	cout << z.get_budget() << " " << z.get_ta()[0].get_payoff() <<endl;

	return 0;
}
