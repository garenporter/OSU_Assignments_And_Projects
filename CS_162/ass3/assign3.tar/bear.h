#include "./animal.h"
#pragma once

class bear : public animal {
	public:
		bear();
};
